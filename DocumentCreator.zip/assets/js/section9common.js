//Generate Segment Menu
$('#segmentMenu').append('<a href="section9.'+extDirect+'" class="item">Purge Configurations - IBE Order</a>');
$('#segmentMenu').append('<a href="section9.demographics.'+extDirect+'" class="item">Purge Configurations - Demographics</a>');
$('#segmentMenu').append('<a href="section9.study.'+extDirect+'" class="item">Study Configurations</a>');
$('#segmentMenu').append('<a href="section9.xcommon.'+extDirect+'" class="item">Xcelera Worklist Common</a>');
$('#segmentMenu').append('<a href="section9.xae.'+extDirect+'" class="item">Xcelera Worklist AE</a>');
$('#segmentMenu').append('<a href="section9.ibeadt.'+extDirect+'" class="item">IBE ADT Orders Worklist</a>');
$('#segmentMenu').append('<a href="section9.patientindex.'+extDirect+'" class="item">Patient Index</a>');
$('#segmentMenu').append('<a href="section9.ibecommon.'+extDirect+'" class="item">IBE Common</a>');
$('#segmentMenu').append('<a href="section9.xreporter.'+extDirect+'" class="item">Xcelera Reporter</a>');