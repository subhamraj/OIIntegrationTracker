

//Generate Segment Menu
$('#segmentMenu').append('<a href="section10.'+extDirect+'" class="item">ADT</a>');
$('#segmentMenu').append('<a href="section10.dicomWorklist.'+extDirect+'" class="item">DICOM Worklist</a>');
$('#segmentMenu').append('<a href="section10.orders.'+extDirect+'" class="item">ORDERS</a>');
$('#segmentMenu').append('<a href="section10.procedures.'+extDirect+'" class="item">PROCEDURES</a>');
$('#segmentMenu').append('<a href="section10.results_pdf.'+extDirect+'" class="item">RESULTS PDF</a>');
$('#segmentMenu').append('<a href="section10.results_text.'+extDirect+'" class="item">RESULTS TEXT</a>');
$('#segmentMenu').append('<a href="section10.results_utr.'+extDirect+'" class="item">RESULTS UTR</a>');

